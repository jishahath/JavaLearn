package studentinfo.v3;

/**
 * Created by jisha on 8/6/17.
 */
public class EmployeeInfo {

    public int empNo;
    public String empName;

    public void printInfo() {
        System.out.println("Emp No: " + empNo + "|EmpName: " +
                empName);
    }

    public void printInfo1(){
        System.out.println("Emp No: " + empNo + "|EmpName: " +
                empName);
    }
}
