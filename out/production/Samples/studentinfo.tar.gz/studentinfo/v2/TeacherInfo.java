package studentinfo.v2;

/**
 * Created by jisha on 5/6/17.
 */
public class TeacherInfo {


    public String name;
    public int regNo;
    public int grade;
    public String subject;


    public void printInfo() {
        System.out.println("Reg no:" + regNo + " | Name: " +
                name + " | Grade: " + grade + " | Subject: " + subject);
    }

    public void printInfo1() {
        System.out.println("Reg no:" + regNo + " | Name: " + name
                + " | Grade: " + grade + " | Subject: " + subject);
    }

}




