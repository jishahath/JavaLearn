package studentinfo.v3;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by jisha on 8/6/17.
 */
public class AdminList {

    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);



        while (true){
            System.out.println("0. Exit");
            System.out.println("1. Teaching Staffs");
            System.out.println("2. Nonteaching Staffs");
            System.out.println("3. Students");
            System.out.println("\n Enter the option: ");

            int option = sc.nextInt();

            switch (option){

                case 0:
                    System.out.println();
                    System.exit(0);
                    break;

                case 1:
                    AdminInfo t = new AdminInfo();

                    ArrayList<AdminInfo> teachers = new ArrayList<>();
                    Scanner sc1 = new Scanner(System.in);


                    while (true){
                        System.out.println("1. Add Teachers");
                        System.out.println("2. Remove Teachers");
                        System.out.println("3. Print Teachers");
                        System.out.println("4. Update");
                        System.out.println("\n Enter the choice: ");

                        int choice = sc1.nextInt();

                        switch (choice) {

                            case 1:
                                System.out.println();
                                System.out.println("Enter teacher regNo");
                                t.regNo = sc1.nextInt();
                                System.out.println("Enter teacher name: ");
                                t.name = sc1.next();
                                System.out.println("Enter grade");
                                t.grade = sc1.nextInt();
                                System.out.println("Enter subject");
                                t.subject = sc1.next();

                                teachers.add(t);

                                break;

                            case 2:
                                System.out.println();
                                System.out.println("Enter the teacher register number to be removed: ");
                                int regNo = sc1.nextInt();

                                AdminInfo teacherToRemove = null;


                                for (AdminInfo t2 : teachers) {
                                    if (t2.regNo == regNo) {
                                        teacherToRemove = t2;
                                        break;
                                    }
                                }

                                if (teacherToRemove != null) {
                                    teachers.remove(teacherToRemove);
                                    System.out.println("Teacher " + teacherToRemove.name + " removed !");
                                } else {
                                    System.out.println("No teacher with regNo " + regNo);
                                }

                                break;
                            case 3:
                                System.out.println();
                                for (AdminInfo t1 : teachers) {
                                    t1.printInfo();
                                }
                                break;
                            case 4:
                                System.out.println();
                                System.out.println("Enter the teacher regNo to be updated");
                                int regNumber = sc1.nextInt();

                                AdminInfo teacherToUpdate = null;
                                for (AdminInfo t3 : teachers) {
                                    if (t3.regNo == regNumber) {
                                        teacherToUpdate = t3;
                                        break;
                                    }
                                }

                                if (teacherToUpdate != null) {
                                    System.out.println("Enter new name (" + teacherToUpdate.name + "): ");
                                    teacherToUpdate.name = sc1.next();
                                    System.out.println("Enter new grade(" + teacherToUpdate.grade + "): ");
                                    teacherToUpdate.grade = sc1.nextInt();
                                    System.out.println("Enter new subject (" + teacherToUpdate.subject + "): ");
                                    teacherToUpdate.subject = sc1.next();
                                } else {
                                    System.out.println("No teacher with reg no" + regNumber);
                                }
                                break;

                            default:
                                System.out.println("INVALID ENTRY");
                                break;

                        }
                    }
                case 2:
                    AdminInfo e = new AdminInfo();

                    ArrayList<AdminInfo> employees = new ArrayList<>();
                    Scanner se = new Scanner(System.in);


                    while (true) {
                        System.out.println("1. Add Employee");
                        System.out.println("2. Remove Employee");
                        System.out.println("3. Print Employee");
                        System.out.println("4. Update");
                        System.out.println("\n Enter the key: ");

                        int key = se.nextInt();

                        switch (key) {

                            case 1:
                                System.out.println();
                                System.out.println("Enter employee no: ");
                                e.empNo = se.nextInt();
                                System.out.println("Enter employee name: ");
                                e.empname = se.next();

                                employees.add(e);

                                break;

                            case 2:
                                System.out.println();
                                System.out.println("Enter the employee number to be removed: ");
                                int empNo = se.nextInt();

                                AdminInfo employeeToRemove = null;


                                for (AdminInfo e2 : employees) {
                                    if (e2.empNo == empNo) {
                                        employeeToRemove = e2;
                                        break;
                                    }
                                }

                                if (employeeToRemove != null) {
                                    employees.remove(employeeToRemove);
                                    System.out.println("Employee " + employeeToRemove.empname + " removed !");
                                } else {
                                    System.out.println("No employee with empNo " + empNo);
                                }

                                break;
                            case 3:
                                System.out.println();
                                for (AdminInfo e1 : employees) {
                                    e1.printInfo2();
                                }
                                break;
                            case 4:
                                System.out.println();
                                System.out.println("Enter the employee No to be updated");
                                int empNumber = se.nextInt();

                                AdminInfo employeeToUpdate = null;
                                for (AdminInfo e3 : employees) {
                                    if (e3.empNo == empNumber) {
                                        employeeToUpdate = e3;
                                        break;
                                    }
                                }

                                if (employeeToUpdate != null) {
                                    System.out.println("Enter new name (" + employeeToUpdate.empname + "): ");
                                    employeeToUpdate.empname = se.next();
                                } else {
                                    System.out.println("No employee with emp no" + empNumber);
                                }
                                break;

                            default:
                                System.out.println("INVALID ENTRY");
                                break;

                        }
                    }

                case 3:
                    AdminInfo s = new AdminInfo();

                    ArrayList<AdminInfo> students = new ArrayList<>();
                    Scanner ss = new Scanner(System.in);

                    while (true) {
                        System.out.println("1. Add Student");
                        System.out.println("2. Remove Student");
                        System.out.println("3. Print student");
                        System.out.println("4. Update");
                        System.out.println("\n Enter the index: ");

                        int index = ss.nextInt();

                        switch (index) {

                            case 1:

                                System.out.println();
                                System.out.println("Enter student name: ");
                                s.studentName = ss.next();
                                System.out.println("Enter student roll number: ");
                                s.rollNo = ss.nextInt();
                                System.out.println("Enter student age: ");
                                s.age = ss.nextInt();
                                System.out.println("Enter ClassName: ");
                                s.className = ss.next();

                                students.add(s);

                                break;
                            case 2:
                                System.out.println();
                                System.out.println("Enter the student roll number to be removed: ");
                                int rollNo = ss.nextInt();

                                AdminInfo studentToRemove = null;


                                for (AdminInfo s2 : students) {
                                    if (s2.rollNo == rollNo) {
                                        studentToRemove = s2;
                                        break;
                                    }
                                }

                                if (studentToRemove != null) {
                                    students.remove(studentToRemove);
                                    System.out.println("student " + studentToRemove.studentName + " removed !");
                                } else {
                                    System.out.println("No student with rollNo " + rollNo);
                                }

                                break;
                            case 3:
                                System.out.println();
                                for (AdminInfo s1 : students) {
                                    s1.printInfo4();
                                }
                                break;
                            case 4:
                                System.out.println();
                                System.out.println("Enter the student roll number to be updated");
                                int rollNumber = ss.nextInt();


                                AdminInfo studentToUpdate = null;
                                for (AdminInfo s3 : students) {
                                    if (s3.rollNo == rollNumber) {
                                        studentToUpdate = s3;
                                        break;
                                    }
                                }

                                if (studentToUpdate != null) {
                                    System.out.println("Enter new name (" + studentToUpdate.studentName + "): ");
                                    studentToUpdate.studentName = ss.next();
                                    System.out.println("Enter new age (" + studentToUpdate.age + "): ");
                                    studentToUpdate.age = ss.nextInt();
                                    System.out.println("Enter new class (" + studentToUpdate.className + "): ");
                                    studentToUpdate.className = ss.next();
                                } else {
                                    System.out.println("No student with roll no" + rollNumber);
                                }
                                break;

                            default :
                                System.out.println("INVALID ENTRY");
                                break;

                        }





            }







            }

        }



    }
}
