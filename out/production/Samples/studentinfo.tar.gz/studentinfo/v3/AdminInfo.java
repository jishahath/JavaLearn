package studentinfo.v3;

/**
 * Created by jisha on 8/6/17.
 */
public class AdminInfo {

    public int regNo;
    public String name;
    public int grade;
    public String subject;
    public int empNo;
    public String empname;
    public int rollNo;
    public String studentName;
    public String className;
    public int age;

    public void printInfo() {
        System.out.println("Reg No: " + regNo + "|Name: " +
                name + "|Grade: " + grade + "|Subject: " + subject);
    }


    public void printInfo1(){
        System.out.println("Reg No: " +regNo + "|Name: " +
                name + "|Grade: " +grade + "|Subject: " +subject);
    }





    public void printInfo2() {
        System.out.println("Emp No: " + empNo + "|EmpName: " +
                empname);
    }


    public void printInfo3(){
        System.out.println("Emp No: " + empNo + "|EmpName: " +
                empname);
    }




    public void printInfo4() {
        System.out.println("Roll no:" + rollNo + " | Name: " +
                studentName + " | age: " + age + " | Class: " + className);
    }

    public void printInfo5() {
        System.out.println("Roll no:" + rollNo + " | Name: " + studentName
                + " | age: " + age + " | Class: " + className);
    }



}
